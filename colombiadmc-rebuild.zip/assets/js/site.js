/* ============================================================
   The Colombian Empire — shared site behavior
   Loaded on every standard page. Handles: scroll-in fades,
   mobile nav, back-to-top, and the synthesized "colonial" UI
   sound set. Page-specific data (citizen rosters, stat targets,
   wiki page title) stays inline on the pages that need it.
   ============================================================ */

/* ---------- Scroll-in fade animation for sections ---------- */
const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };
const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.animation = 'fadeInUp 0.8s ease-out forwards';
      sectionObserver.unobserve(entry.target);
    }
  });
}, observerOptions);
document.querySelectorAll('.section, .town-card, .gov-pill, .standing-card, .treaty-item, .event, .perk-card, .step').forEach(el => {
  el.style.opacity = '0';
  sectionObserver.observe(el);
});

/* ---------- Mobile nav toggle ---------- */
const navToggle = document.getElementById('navToggle');
const navLinks = document.getElementById('navLinks');
const navScrim = document.getElementById('navScrim');
if (navToggle && navLinks) {
  function closeNav() {
    navToggle.classList.remove('open');
    navLinks.classList.remove('open');
    navToggle.setAttribute('aria-expanded', 'false');
    if (navScrim) navScrim.classList.remove('open');
  }
  navToggle.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    navToggle.classList.toggle('open', isOpen);
    navToggle.setAttribute('aria-expanded', String(isOpen));
    if (navScrim) navScrim.classList.toggle('open', isOpen);
  });
  if (navScrim) navScrim.addEventListener('click', closeNav);
  navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', closeNav));
}

/* ---------- Back-to-top button ---------- */
const backToTop = document.getElementById('backToTop');
if (backToTop) {
  function onScroll() {
    backToTop.classList.toggle('visible', window.scrollY > 500);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
  backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
}

/* ---------- UI sounds — "colonial" set ----------
   Click = coin clink (two metallic overtones, like gold changing hands)
   Hover = soft bell tink (single quiet harmonic ping)
   Modal = hand-bell chime with real overtones, like an old clock/hand bell
   All synthesized live via Web Audio — no audio files needed.
   Browsers block audio until the user's first interaction with the page;
   that's normal, not a bug — everything works after the first click.
*/
let audioCtx;
function getCtx() {
  audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
  return audioCtx;
}

function playUiClick() {
  try {
    const ctx = getCtx();
    const now = ctx.currentTime;
    [1450, 2150].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.85, now + 0.09);
      gain.gain.setValueAtTime(i === 0 ? 0.045 : 0.025, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.13);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.13);
    });
  } catch (e) { /* fail silently */ }
}
document.querySelectorAll('.nav-links a, .btn, .home-btn, .nav-toggle, .citizen-card, .standing-card, .treaty-item, .perk-card').forEach(el => {
  el.addEventListener('click', playUiClick);
});

let lastHoverSound = 0;
function playUiHover() {
  const now0 = performance.now();
  if (now0 - lastHoverSound < 100) return;
  lastHoverSound = now0;
  try {
    const ctx = getCtx();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1600, now);
    gain.gain.setValueAtTime(0.018, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.09);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.09);
  } catch (e) { /* fail silently */ }
}
document.querySelectorAll('.nav-links a, .btn, .citizen-card, .standing-card, .treaty-item, .perk-card').forEach(el => {
  el.addEventListener('mouseenter', playUiHover);
});

function playChime(rising) {
  try {
    const ctx = getCtx();
    const now = ctx.currentTime;
    const base = rising ? 520 : 460;
    const overtones = [1, 2.4, 3.9];
    const gains = [0.05, 0.022, 0.012];
    overtones.forEach((mult, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      const freq = base * mult;
      osc.frequency.setValueAtTime(freq, now);
      if (rising) {
        osc.frequency.exponentialRampToValueAtTime(freq * 1.15, now + 0.12);
      } else {
        osc.frequency.exponentialRampToValueAtTime(freq * 0.9, now + 0.2);
      }
      gain.gain.setValueAtTime(gains[i], now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.45 - i * 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.45);
    });
  } catch (e) { /* fail silently */ }
}
window.playChime = playChime; // used by page-specific profile modals

/* ---------- Magnetic buttons ---------- */
document.querySelectorAll('.btn').forEach(btn => {
  btn.addEventListener('mousemove', (e) => {
    const rect = btn.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    btn.style.transform = `translate(${x * 0.18}px, ${y * 0.35 - 3}px)`;
  });
  btn.addEventListener('mouseleave', () => {
    btn.style.transform = '';
  });
});

/* ---------- Anthem toggle (present on pages with the sidebar player) ---------- */
const anthemBtn = document.querySelector('.music-btn');
if (anthemBtn) {
  anthemBtn.addEventListener('click', () => {
    const audio = document.getElementById('hidden-audio');
    if (!audio) return;
    audio.paused ? audio.play() : audio.pause();
  });
}
