# colombiadmc.site — Rebuild Notes

Everything here is a drop-in replacement for the repo root. It keeps your
existing GitHub Pages deploy workflow (`.github/workflows/static.yml`)
completely unchanged — no build step, no new hosting setup, same CNAME.

## How to deploy
1. In `WOL321/colombia`, create a new branch (e.g. `rebuild`).
2. Delete everything in the branch **except** `.git`.
3. Copy every file from this zip into the repo root, replacing what's there.
4. Commit, push, open a PR against `main` so you can preview it (GitHub
   will build a deploy preview) before merging.
5. Once you're happy, merge — the existing Pages workflow picks it up
   automatically, same as always.

## What changed and why

**Structure**
- All CSS that was previously copy-pasted into a `<style>` block on every
  page now lives in one file: `assets/css/style.css`. Change a color or
  the nav once, it updates everywhere.
- All shared interactive behavior (mobile nav, back-to-top, the coin-click
  / bell-hover sound design, magnetic buttons, scroll-reveal animations)
  now lives in `assets/js/site.js`, loaded on every page instead of being
  duplicated six times with six chances to drift out of sync.
- Images moved into `assets/images/`, audio into `assets/`, with real
  descriptive filenames instead of screenshot defaults.

**Bugs fixed**
- The navbar brand slot (`.nav-brand`) was empty on *every single page* —
  the CSS for a logo + wordmark existed but nothing was ever put in it, so
  there was no way to click back home from the nav. Fixed site-wide.
- `salento.html` referenced its images with a `../` prefix, which pointed
  one level above the site root and 404'd. Fixed.
- `casino.html` referenced `'Cinzel'` in its font stack but never actually
  loaded the Google Fonts file for it, so headings were silently falling
  back to plain serif. Added the font link.
- `sports.html` was a completely different, unfinished page — Times New
  Roman font, no nav, no footer, no brand colors, none of the site's
  design system. Rebuilt from scratch to match the rest of the site.
- Fleshed out `barbados.html`, `salento.html`, `tegucigalpa.html`, which
  were bare stubs (two raw images, no nav, no footer, no real content)
  into full pages with real copy, matching the site's standard.
- `sitemap.xml` was missing four real pages (`history.html`,
  `diplomacy.html`, `join.html`, `casino.html`) — added them.

**Images**
- All images used on the site were compressed and resized sensibly.
  Combined weight of the site's used images went from **4.3MB → 252KB**
  (~94% smaller) with no visible quality loss.
- ~2.8MB of orphaned images that were sitting in the repo but never
  actually referenced anywhere were dropped from this build. They're
  still in your git history if you ever need them — just weren't linked
  to anything.

**Design system**
- Colors are now CSS custom properties (`--gold`, `--bg`, `--text-muted`,
  etc.) instead of hardcoded hex values scattered through 700+ lines.
  Rebrand or retheme in one place if you ever want to.
- Added consistent focus states, `prefers-reduced-motion` support, and a
  few other accessibility basics that were inconsistent page to page.
- Extended the sound design and hover/reveal animations that only
  `index.html` had to every other page, so the whole site feels equally
  polished instead of the homepage being noticeably nicer than the rest.

## One thing worth knowing (didn't change this — your call)
The homepage stat counter animates `statCitizens` up to **70**, but the
actual citizen roster array in the code only lists **~50** names (6
leaders + 44 citizens). Didn't want to invent a number or silently trim
the display — just flagging it so you can update whichever one is stale.

## Not touched
`casino.html`'s blackjack game logic and its own felt-table color theme
were left alone — it's intentionally a different visual mode (like a
fullscreen mini-app) and didn't need fixing, just the font bug above.
